const Notifier = require('./lib/notifier')

module.exports = new Notifier()
