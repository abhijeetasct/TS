var contextMenus = {};

exports.create = function() {

}

exports.update = function() {

}

exports.remove = function() {

}

exports.removeAll = function() {

}
